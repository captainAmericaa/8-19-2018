function check(){
var r=confirm("Do you want to delete the product");
if(r==true)
alert("Product has been deleted");
return true;
}